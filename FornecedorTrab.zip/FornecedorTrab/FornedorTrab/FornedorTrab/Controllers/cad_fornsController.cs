﻿using FornedorTrab.Context;
using FornedorTrab.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace FornedorTrab.Controllers
{
    public class cad_fornsController : Controller
    {
        private readonly AppCont _appcont;

        public cad_fornsController(AppCont appcont)
        {
            _appcont = appcont;
        }

        public IActionResult Index()
        {
            var result = _appcont.cad_Forns.ToList();
            return View(result);
        }

        // ativação da tela de detalhes
        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cad_forns = await _appcont.cad_Forns
                .Include(x => x.Endereco)  // Inclui o Endereco relacionado
                .FirstOrDefaultAsync(x => x.ID == id);

            if (cad_forns == null)
            {
                return BadRequest();
            }

            return View(cad_forns);
        }

        // GET: Criação de fornecedor
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(fornecedor cad_Forn)
        {
            if (ModelState.IsValid)
            {
                _appcont.Add(cad_Forn);
                await _appcont.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(cad_Forn);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }


            var cad_forns = await _appcont.cad_Forns
                .Include(x => x.Endereco)  // Inclui o Endereco relacionado
                .FirstOrDefaultAsync(x => x.ID == id);

            if (cad_forns == null)
            {
                return BadRequest();
            }
            return View(cad_forns);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int? id, fornecedor cad_forn)
        {
            if (id == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _appcont.Update(cad_forn);
                await _appcont.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(cad_forn);

        }

        [HttpGet] // fazer a tela de delete
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var cad_forns = await _appcont.cad_Forns
                .Include(x => x.Endereco)  // Inclui o Endereco relacionado
                .FirstOrDefaultAsync(x => x.ID == id);

            if (cad_forns == null)
            {
                return NotFound();
            }
            return View(cad_forns);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cad_forn = await _appcont.cad_Forns.FindAsync(id);
            _appcont.cad_Forns.Remove(cad_forn);
            await _appcont.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
