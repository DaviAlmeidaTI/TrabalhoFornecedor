﻿using FornedorTrab.Models;

namespace FornedorTrab.Context
{
    public class AppDBInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppCont>();
                context.Database.EnsureCreated();

                //Criar cadastro dos fornecedores
                if (!context.cad_Forns.Any())
                {
                    context.cad_Forns.AddRange(new List<fornecedor>()
                    {
                        new fornecedor()
                        {
                            razao_social = "Nome teste1",
                            Nome_fant_forn = "teste1",
                            Email = "teste1@forncedor.com.br",
                            CNPJ = "14.asd.124/d442-62",
                            Phone = 992312311,
                            Endereco = new Endereco()
                            {
                                Rua = "Rua teste1",
                                Numero = 123,
                                Cidade = "Ribeirão teste",
                                Estado = "São Paulo",
                                CEP = "14564-654"

                            }

                        },
                        new fornecedor()
                        {
                            razao_social = "Nome teste2",
                            Nome_fant_forn = "teste2",
                            Email = "teste2@forncedor.com.br",
                            CNPJ = "12.dgs.12a/cd12-15",
                            Phone = 992312311,
                            Endereco = new Endereco()
                            {
                                Rua = "Travessa teste2",
                                Numero = 123,
                                Cidade = "Ribeirão teste",
                                Estado = "minas testes",
                                CEP = "14524-654"

                            }

                        },
                        new fornecedor()
                        {
                            razao_social = "Nome teste3",
                            Nome_fant_forn = "teste3",
                            Email = "teste3@forncedor.com.br",
                            CNPJ = "12.dgs.12a/cd12-18",
                            Phone = 992312311,
                            Endereco = new Endereco()
                            {
                                Rua = "Rua teste3",
                                Numero = 123,
                                Cidade = "são tome dos Letras",
                                Estado = "São Paulo",
                                CEP = "14224-654"

                            }

                        },
                    });
                    context.SaveChanges();
                }
            }
        }
    }
}
