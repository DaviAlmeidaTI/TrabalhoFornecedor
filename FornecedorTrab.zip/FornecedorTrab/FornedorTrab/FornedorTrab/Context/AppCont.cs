﻿using FornedorTrab.Models;
using Microsoft.EntityFrameworkCore;

namespace FornedorTrab.Context
{
    public class AppCont : DbContext
    {
        public AppCont(DbContextOptions<AppCont> options) : base(options)
        {

        }

        public DbSet<fornecedor> cad_Forns { get; set; }

        public DbSet<Endereco> endereco { get; set; }

    }
}
