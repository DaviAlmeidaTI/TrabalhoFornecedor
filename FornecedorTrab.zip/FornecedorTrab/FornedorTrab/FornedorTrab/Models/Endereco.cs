﻿using System.ComponentModel.DataAnnotations;

namespace FornedorTrab.Models
{
    public class Endereco
    {
        [Key]
        public int ID { get; set; }

        [Required]
        [Display(Name = "Rua")]
        public string Rua { get; set; }

        [Display(Name = "Número")]
        public int Numero { get; set; }

        [Display(Name = "Cidade")]
        public string Cidade { get; set; }

        [Display(Name = "Estado")]
        public string Estado { get; set; }

        [Display(Name = "CEP")]
        public string CEP { get; set; }
    }
}
