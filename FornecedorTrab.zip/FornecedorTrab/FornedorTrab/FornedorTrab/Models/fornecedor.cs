﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FornedorTrab.Models
{
    public class fornecedor
    {
        // Requisitos para criar o banco de dados
        [Key]
        public int ID { get; set; }

        [Required]
        [Display(Name = "Razão social")]
        public string razao_social { get; set; }

        [Required]
        [Display(Name = "Nome fantasia")]
        public string Nome_fant_forn { get; set; }

        public string Email { get; set; }

        [Required]
        [RegularExpression(@"\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$", ErrorMessage = "O CNPJ precisa ser digitado na formatação correta Ex: 12.345.123/0001-12")]
        public string CNPJ { get; set; }

        [Display(Name = "Telefone")]
        public int Phone { get; set; }

        // Chave estrangeira para Endereco
        [ForeignKey("Endereco")]
        public int EnderecoID { get; set; }

        // Propriedade de navegação
        public Endereco Endereco { get; set; }
    }
}
